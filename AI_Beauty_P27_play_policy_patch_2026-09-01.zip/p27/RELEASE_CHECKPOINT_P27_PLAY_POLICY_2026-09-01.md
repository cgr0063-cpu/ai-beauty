# AI Beauty P27 — Google Play policy build patch

## Changes
- Android versionCode: 3
- App version: 0.9.1
- Android compileSdkVersion / targetSdkVersion: 36
- Android buildToolsVersion: 36.0.0
- RevenueCat React Native SDK: ^9.0.0 (uses Google Play Billing Library 8+)
- Added expo-build-properties ~0.12.5 for managed/prebuild Android SDK overrides
- Blocked legacy/unneeded Android permissions: SYSTEM_ALERT_WINDOW, READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE
- Removed stale package-lock.json so the next clean install resolves the upgraded native dependencies instead of reusing Billing 6.x.

## Required verification on next native build
- Play Console must show version code 3 and target SDK 36.
- Play Console must no longer report Billing Library 6.2.1.
- Physical-device smoke test must cover login, camera/selfie, Fit Check, AI backend, subscription/paywall and restore.
